#! /bin/bash
esLaborable() {
# en las primeras 3 lineas buscamos pasara la fecha como parametro y luego en l segunda hacemos que nos devuelva el dia de la semana ( 1 a 5 dia de semana, y 0 y 6 es fin de semana y en la tercera linea hacemos que nos devuelva la fecha en mmdd para saber si es un feriado y luego los comparamos mas abajo en los elif y si es el else evalua el numero del dia de la semana		
	DATE=$1
	FECHA=$(date --date $DATE  +%w)
	FECHA_FERIADO=$(date --date $DATE  +%m%d)

	if [ $FECHA_FERIADO -eq "0101" ];
	then
	echo "es un dia no laborable por que es año nuevo" 
	elif
	[ $FECHA_FERIADO -eq "0324" ];then
	echo "es un dia no laborable por que es el dia de la memoria"
	elif
 	[ $FECHA_FERIADO -eq 0402 ];then
	echo "es un dia no laborable por que el dia de los veteranos y caidos e malvinas"

	elif [ $FECHA_FERIADO -eq 0501 ];then
	echo "es un dia no laborable por que es el dia del trabajo"
	
 	elif [ $FECHA_FERIADO -eq 0525 ]; then
	echo "es un dia no laborable por que es el aniversario de la revolucion de mayo"
 	elif [ $FECHA_FERIADO -eq 0620 ]; then
	echo "es un dia no laborable por el paso a la inmortalidad de manuel belgrano"

 	elif [ $FECHA_FERIADO -eq 0709 ]; then
	echo "es un dia no laborable por que es el dia de la independencia" 
	elif [ $FECHA_FERIADO -eq 0817 ]; then
	echo "es un dia no laborable por el paso a la inmortalidad de san martin"
	
 	elif [ $FECHA_FERIADO -eq 1012 ]; then
	echo "es un dia no laborable por el respeto a la diversidad cultural" 
	elif [ $FECHA_FERIADO -eq 1120 ]; then
	echo "dia no laborable por el dia de la soberania nacional"

 	elif [ $FECHA_FERIADO -eq 1208 ]; then
	echo "es un dia no laborable por que es el dia de la inmaculada concepcion de maria"

	elif [ $FECHA_FERIADO -eq 1225 ];
	then
	echo "es un dia no laborable por navidad"
	

	else
		if [ $FECHA -eq "1" ] || [ $FECHA -eq "2" ] || [ $FECHA -eq "3" ] || [ $FECHA -eq "4" ] || [ $FECHA -eq "5" ];
		then	
			echo "es un dia laborable"
		else
			echo "es un dia no laborable"
		fi
	fi
	echo $FECHA
}
